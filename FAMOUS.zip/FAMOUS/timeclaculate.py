#str.replace('(',"").replace(")","").split()[-1][:-1]

fp = open("timetaken.txt",'r')
SIZE = 0
TIME = 0.0
TOTAL = 0

for line in fp.readlines():
	SIZE += int(line.replace('(',"").replace(")","").split()[2])
	TIME += float(line.replace('(',"").replace(")","").split()[-1][:-1])
	TOTAL +=1
fp.close()

print SIZE, TIME , SIZE / TIME

print "Total applications: {}".format(TOTAL)
print "Total size in Bytes {}, in Kilo Bytes {}".format(SIZE, SIZE / 1000.0)
print "Total time taken in seconds {}, in minutes {}".format(TIME, TIME / 60.0)



